const express = require('express')
const app = express()
const port = 3000
var path = require('path');
var bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({ extended: false }));

var usernameReg;
var passwordReg;

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname + '/registrazione.html'));
})

app.post('/login', (req, res) => {

    usernameReg = req.body.UsernameReg;
    passwordReg = req.body.PasswordReg;
    console.log(usernameReg, passwordReg);
    res.sendFile(path.join(__dirname + '/login.html'));
    //localStorage.setItem('user', usernameReg);
    //localStorage.setItem('password', passwordReg);
  });

  app.post('/homepage-registrati', (req,res) => {
    let usernameLog = req.body.UsernameLog;
    let passwordLog = req.body.PasswordLog;
    //var usernameReg = localStorage.getItem("user");
    //var passwordReg = localStorage.getItem("password");
    //console.log(usernameReg, passwordReg);
    //console.log(usernameLog, passwordLog);

    if (usernameLog == usernameReg && passwordLog == passwordReg) {
        res.sendFile(path.join(__dirname + '/homepage-registrati.html'));
    }
    else {
        res.sendFile(path.join(__dirname + '/homepage-no.html'));
    }
    
  });

app.listen(port, () => {
    
  })